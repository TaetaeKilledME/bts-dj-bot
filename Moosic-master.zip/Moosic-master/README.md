# Moosic

**Host your own 24/7 Discord Music Bot!**

Moosic is a simple bot that is easy to host and setup.
Once setup, moosic will join the designated voice channel and play songs randomly from songs.txt 24/7.

## Instructions
**First setup your bot by following the guide [Here](https://github.com/Repulser/Moosic/wiki/Setting-up-the-bot-for-the-first-time)**

You can host the bot for free by following [this](https://github.com/Repulser/Moosic/wiki/Hosting-on-heroku-for-free) guide

**Or host it yourself by following [this](https://github.com/Repulser/Moosic/wiki/Running-the-bot) guide.**
